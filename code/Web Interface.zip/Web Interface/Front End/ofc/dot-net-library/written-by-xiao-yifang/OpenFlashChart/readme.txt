you can visit my blog
http://xiao-yifang.blogspot.com

written in chinese ,wish you can read:-)