using System;
using System.Collections.Generic;
using System.Text;

namespace OpenFlashChart
{
    public class Area:AreaBase
    {
    }
}
