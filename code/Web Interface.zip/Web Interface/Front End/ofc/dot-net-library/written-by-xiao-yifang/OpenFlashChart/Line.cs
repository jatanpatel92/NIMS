using System;
using System.Collections.Generic;
using System.Text;

namespace OpenFlashChart
{
    public class Line : LineBase
    {
        public Line()
        {
            this.ChartType = "line";
        }
    }
}
